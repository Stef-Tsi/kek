<?php
    $this->conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
?>