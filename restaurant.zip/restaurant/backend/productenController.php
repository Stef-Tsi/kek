<?php

    class productenController
    {
        public $conn;
        public function __construct()
        {
            $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
            $this->conn = $conn;
        }
        

    public function ProductenOphalen() {
        $query = "SELECT * FROM menuitems";
        $stm = $this->conn->prepare($query);
        if($stm->execute()==true){
            $product = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($product as $product){
                echo "<tr>";
                ?>
                 
                    <div class="product">
                        <div class="col"><img src=<?=$product->img?> height="55" class="rounded mx-auto d-block" alt="alt"></div>
                        <div class="col"><b>Naam:</b> <?= $product->naam?></div>
                        <div class="col"><b>Prijs:</b> €<?= $product->prijs?></div>
                        <button type="button" class="btn btn-secondary ">Toevoegen</button>
                        

                    </div>
                
                <?php
                }
            }
        }

    public function ProductCatagorie(){
        $query = "SELECT * FROM categorien";
        $stm = $this->conn->prepare($query);
        if($stm->execute()==true){
            $catag = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($catag as $catag){
                echo "<tr>";
                ?>
                 <li><a class="dropdown-item" href="#"><?= $catag->naam?></a></li>
            
                <?php
                }
            }
    }
}
?>