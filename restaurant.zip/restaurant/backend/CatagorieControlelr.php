<?php

    class catagorieController
    {
        public $conn;
        public function __construct()
        {
            $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
            $this->conn = $conn;
        }
        

    

    public function ProductCatagorie(){
        $query = "SELECT * FROM categorien";
        $stm = $this->conn->prepare($query);
        if($stm->execute()==true){
            $catag = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($catag as $catag){
                echo "<tr>";
                ?>
                 <li><a class="dropdown-item" href="#"><?= $catag->naam?></a></li>
        
                <?php
                }
            }else echo" werkt niet" ;
    }
}
?>