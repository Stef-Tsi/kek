<?php
class reservatieController
{
    public $conn;
    public function __construct()
    {
        $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
        $this->conn = $conn;
    }

    public function getListReservatie() {
        $query = "SELECT * FROM reserveringen INNER JOIN klanten ON klanten.KID = reserveringen.RID;";
        $stm = $this->conn->prepare($query);
        if($stm->execute()==true){
            $reserveringen = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($reserveringen as $reservering){
                echo "<tr>";
                ?>
                <div class="container-fluid">   
                    <div class="row row-cols-6 mt-3 reserveringTable">
                        <div class="col"><b>Tafel nummer:</b> <?= $reservering->tafel?></div>
                        <div class="col"><b>Datum:</b> <?= $reservering->datum?></div>
                        <div class="col"><b>Naam:</b> <?= $reservering->naam?></div>
                        <div class="col"><b>Aantal personen:</b> <?= $reservering->aantal?></div>
                        <div class="col"><b>Allergieen:</b> <?= $reservering->allergieen?></div>
                        <div class="col"><?php echo "<a href=overzichtBestellingen.php?ID=".$reservering->RID.">Bekijken bestelling</a>"; ?></div>
                        <div class="col"><b>Status:</b> <?= $reservering->status?></div>
                        <div class="col"><b>Datum toegevoegd:</b> <?= $reservering->datum_toegevoegd?></div>
                        <div class="col"><b>Reserverings tijd:</b> <?= $reservering->tijd?></div>
                        <div class="col"><b>Aantal kinderen:</b> <?= $reservering->aantal_k?></div>
                        <div class="col"><b>Opmerkingen:</b> <?= $reservering->opmerkingen?></div>
                        <div class="col"><?php echo "<a href=kassa.php?ID=".$reservering->RID.">Betaal bestelling</a>"; ?></div>

                        <br><br>
                    </div>
                </div>
                <?php
            }
        }
    }
}


?>
