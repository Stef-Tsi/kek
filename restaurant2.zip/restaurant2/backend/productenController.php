<?php

    class productenController
    {

        //Connectie leggen met de database
        public $conn;
        public function __construct()
        {
            $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
            $this->conn = $conn;
        }
        

    public function ProductenOphalen() {

        //STAP 1 - Query schrijven
        $query = "SELECT * FROM menuitems";

        //STAP 2 - Query Inlezen
        $stm = $this->conn->prepare($query);

         //STAP 3 - Query uitvoeren en items showen
        if($stm->execute()==true){
            $product = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($product as $product){
                ?>
                    <div class="productContainer">
                        <div class="product">
                            <div class="col"><b>ID:</b> <?= $product->MID?></div>
                            <div class="col"><img src=<?=$product->img?> height="55" class="rounded mx-auto d-block" alt="alt"></div>
                            <div class="col"><b>Naam:</b> <?= $product->naam?></div>
                            <div class="col"><b>Prijs:</b> €<?= $product->prijs?></div>
                        </div>       
                    </div>
                
                <?php
            }
        }
        if (isset($_POST['btnBestel'])){ 
            $BID = 0;
            $RID = $_POST['RID'];
            $MID = $_POST['MID'];
            $aantal = $_POST['aantal'];
            $geserveerd = $_POST['geserveerd'];

            $query = "INSERT into bestellingen VALUES (:BID,
                                                    :RID,
                                                    :MID,
                                                    :aantal,
                                                    :geserveerd)";

            $stm = $this->conn->prepare($query);
            $stm->bindParam(":BID", $BID);
            $stm->bindParam(":RID", $RID);
            $stm->bindParam(":MID", $MID);
            $stm->bindParam(":aantal", $aantal);
            $stm->bindParam(":geserveerd", $geserveerd);

            if($stm->execute() == true){
                echo "het werkt!";
            }else echo "Geen gegevens verstuurd!";
          }
}}
?>