<?php
class betalenController
{

    //Connectie leggen met de database

    public $conn;
    public function __construct()
    {
        $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
        $this->conn = $conn;
    }

    public function betallBonOphallen() {
        
        //Variablen ophalen van het id vroige pagine
        $ID = $_GET['ID'];

        //STAP 1 - Query schrijven
        $query = "SELECT * FROM bestellingen INNER JOIN menuitems ON bestellingen.menuitem_ID = menuitems.MID where reservering_ID = :ID";

        //STAP 2 - Query Inlezen
        $stm = $this->conn->prepare($query);

        //STAP 3 - aliassen koppelen aan waarden
        $stm->bindParam(":ID", $ID);

        //STAP $ - Query uitvoeren en items showen
        if($stm->execute()==true){
            $bestellingen = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($bestellingen as $bestelling){
                echo "<tr>";
                ?>
                <div class="container-fluid bestellingContainer">
                    <div class="row row-cols-3 mt-3 bestellingTable">
                        
                        <div class="col"><b>Naam: <?= $bestelling->naam?></b></div>
                        <div class="col"><b>Aantal: <?= $bestelling->aantal?></b></div>
                        <div class="col"><b>Aantal: <?= $bestelling->prijs?></b></div>    
                    </div>
                </div>
                <?php
            }
        }
    }

}


?>
