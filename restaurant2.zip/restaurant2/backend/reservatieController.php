<?php
class reservatieController
{

    //Connectie leggen met de database
    public $conn;
    public function __construct()
    {
        $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
        $this->conn = $conn;
    }

    public function getListReservatie() {

        //STAP 1 - Query schrijven
        $query = "SELECT * FROM reserveringen INNER JOIN klanten ON klanten.KID = reserveringen.RID;";

        //STAP 2 - Query Inlezen
        $stm = $this->conn->prepare($query);

        //STAP 3 - Query uitvoeren en items showen
        if($stm->execute()==true){
            $reserveringen = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($reserveringen as $reservering){
                echo "<tr>";
                ?>
                <div class="container-fluid">   
                    <div class="row row-cols-6 mt-3 reserveringTable">
                        <div class="col"><b>Tafel nummer:</b> <?= $reservering->tafel?></div>
                        <div class="col"><b>Datum:</b> <?= $reservering->datum?></div>
                        <div class="col"><b>Naam:</b> <?= $reservering->klantNaam?></div>
                        <div class="col"><b>Aantal personen:</b> <?= $reservering->aantal_v?></div>
                        <div class="col"><b>Allergieen:</b> <?= $reservering->allergieen?></div>
                        <div class="col"><?php echo "<a href=bestellen.php?ID=".$reservering->RID.">Bestelling plaatsen</a>"; ?></div>
                        <div class="col"><b>Status:</b> <?= $reservering->status?></div>
                        <div class="col"><b>Datum toegevoegd:</b> <?= $reservering->datum_toegevoegd?></div>
                        <div class="col"><b>Reserverings tijd:</b> <?= $reservering->tijd?></div>
                        <div class="col"><b>Aantal kinderen:</b> <?= $reservering->aantal_k?></div>
                        <div class="col"><b>Opmerking:</b> <?= $reservering->opmerkingen?></div>
                        <div class="col"><?php echo "<a href=kassa.php?ID=".$reservering->RID.">Betaal bestelling</a>"; ?></div>
                        <div class="col"><?php echo "<a href=klantGegevens.php?ID=".$reservering->KID.">Klant gegevens invoegen</a>"; ?></div>

                        <br><br>
                    </div>
                </div>
                <?php
            }
        }
    }


    public function klantGegevensOphalen() {

        $ID = $_GET['ID'];

        $query = "SELECT * FROM klanten where KID = :ID";

        //STAP 2 - Query Inlezen
        $stm = $this->conn->prepare($query);

        $stm->bindParam(":ID", $ID);

        //STAP 3 - Query uitvoeren en items showen
        if($stm->execute()==true){
            $klant = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($klant as $klant){
                ?>
                <div class="form-group klant">
                    <label for="exampleFormControlInput1">ID:</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1"  name="KID" value="<?= $klant->KID?>" placeholder="<?= $klant->KID?>" readonly>
                </div>

                <div class="form-group klant">
                    <label for="exampleFormControlInput1">Klant naam:</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1"  name="klantNaam" value="<?= $klant->klantNaam?>" placeholder="<?= $klant->klantNaam?>" readonly>
                </div>

                <div class="form-group klant">
                    <label for="exampleFormControlInput1">Telefoon nummer:</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1"  name="telefoon" value="<?= $klant->telefoon?>" placeholder="<?= $klant->telefoon?>" readonly>
                </div>

                <div class="form-group klant">
                    <label for="exampleFormControlInput1">Email:</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1"  name="email" value="<?= $klant->email?>" placeholder="<?= $klant->email?>" readonly>
                </div>


                <?php
            }
        }
    }
}


?>
