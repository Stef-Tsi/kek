<?php
class bestelController
{
    //Connectie maken met de database
    public $conn;
    public function __construct()
    {
        $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
        $this->conn = $conn;
    }

    public function getListBestelling() {

        //Variablen ophalen van het id vroige pagine
        $ID = $_GET['ID'];

        //STAP 1 - Query schrijven
        $query = "SELECT * FROM bestellingen INNER JOIN menuitems ON bestellingen.menuitem_ID = menuitems.MID INNER JOIN reserveringen ON bestellingen.reservering_ID = reserveringen.RID INNER JOIN klanten ON reserveringen.klant_ID = klanten.KID WHERE reserveringen.RID = :ID;";

        //STAP 2 - Query Inlezen
        $stm = $this->conn->prepare($query);

        //STAP 3 - aliassen koppelen aan waarden
        $stm->bindParam(":ID", $ID);

        //STAP $ - Query uitvoeren en items showen
        if($stm->execute()==true){
            $bestellingen = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach($bestellingen as $bestelling){
                ?>
                <table class="body-wrap">
        <tbody><tr>
            <td></td>
            <td class="container" width="600">
                <div class="content">
                    <table class="main" width="100%" cellpadding="0" cellspacing="0">
                        <tbody><tr>
                            <td class="content-wrap aligncenter">
                                <table width="100%" cellpadding="0" cellspacing="0">
                                    <tbody><tr>
                                        <td class="content-block">
                                            <h2>Restuarant Excellent Taste</h2>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="content-block">
                                            <table class="invoice">
                                                <tbody><tr>
                                                    <td>Naam: <?= $bestelling->klantNaam?><br>Bestelling: <?= $bestelling->BID?><br><?= $bestelling->datum?></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <table class="invoice-items" cellpadding="0" cellspacing="0">
                                                            <tbody><tr>
                                                                <td><p>Naam: <?= $bestelling->naam?> </p><p>Prijs: €<?= $bestelling->prijs?> </p><p>Aantal: <?= $bestelling->aantal?> </p></td>
                                                                
                                                            </tr>
                                                            
                                                            <tr class="total">
                                                                <td class="alignright" width="80%">Totaal</td>
                                                                <td class="alignright">€  <?= $bestelling->aantal * $bestelling->prijs?></td>
                                                            </tr>
                                                        </tbody></table>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="content-block">
                                            <a href="#">View in browser</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="content-block">
                                            Restuarant Inc. kniplijn 11, roosendaal 4415ET
                                        </td>
                                    </tr>
                                </tbody></table>
                            </td>
                        </tr>
                    </tbody></table>
                    <div class="footer">
                        <table width="100%">
                            <tbody><tr>
                                <td class="aligncenter content-block">Vragen? Email <a href="mailto:">support@ExcellentTaste.nl</a></td>
                            </tr>
                        </tbody></table>
                    </div></div>
            </td>
            <td></td>
        </tr>
    </tbody></table>
                <?php
            }
        }
    }

}


?>
