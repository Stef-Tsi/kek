<?php
class overzichtController
{
     //Connectie leggen met de database

    public $conn;
    public function __construct()
    {
        $conn = new PDO("mysql:host=localhost;dbname=restaurant;", "root", "");
        $this->conn = $conn;
    }

    public function overzicht()
    {
        //STAP 1 - Query schrijven
        $query = "SELECT * FROM bestellingen INNER JOIN menuitems ON menuitems.MID = bestellingen.menuitem_ID
        INNER JOIN reserveringen ON bestellingen.reservering_ID = reserveringen.RID WHERE gerechtsoort_ID = '2'";

        //STAP 2 - Query Inlezen
        $stm = $this->conn->prepare($query);

        //STAP 3 - Query uitvoeren en items showen
        if ($stm->execute() == true) {
            $bestellingen = $stm->fetchAll(PDO::FETCH_OBJ);
            foreach ($bestellingen as $besteld) {
                echo "<tr>";
?>                  
                        <div >
                            <b>Tafel: </b><?= $besteld->tafel ?></b>
                            <b>Naam: </b><?= $besteld->naam ?></b>
                            <b>Aantal: </b><?= $besteld->aantal ?></b>
                        
                        </div>
                       
<?php
            }
        }
    }
}
?>